# Term Project Deliverable 2: Remote Message Storage

## Usage: curl -X GET -H "Content-Type: application/json" -d "1234 dogs" localhost:8080
    # The curl command must be a GET message
    # The body must be a number, which is used as a password. Put at least one space after the number, and put a message after.
    # If there is already a message with that password, it will be returned to you
    # If you want to check a message without updating it, simply send the password without any spaces. 

### Dependencies

 - Maven
 - Java JDK 8

### Build

 - run `$ mvn clean && mvn package`

### Run

 - run `$java -jar TP2R.jar`

### docker

 - `$ docker build -t <tagname> .`
 - `$ docker run -it --name=<tagname> 8080:8080 <tagname>`

### Note
 - The project can be run with the run file with `$ ./run.sh`

Message #general



# Deliverable 3 Update:

### The curl command from deliverable 2 still works, though the IP address and ports ned to be altered. 

### Run Kubernetes:

 - `$ kubectl apply -f deployment.yaml`

### Get IP address:

 - `$ kubectl describe service message-service`
 - Kubernetes port is 30076

### Send request:

 - `$ curl -X GET -H "Content-Type: application/json" -d "1235 Thisisamessage" http://172.17.0.2:30076`
