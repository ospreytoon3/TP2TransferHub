#!/bin/sh

docker rm tp-i
docker build -t tp-i .
docker run -it --name=tp-i -p 8080:8080 tp-i
